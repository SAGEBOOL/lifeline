// 人生运势命理K线图 - 核心逻辑

// 天干地支
const TIAN_GAN = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const DI_ZHI = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

// 天干五行对应
const GAN_WUXING: Record<string, string> = {
  '甲': '木', '乙': '木', '丙': '火', '丁': '火', '戊': '土',
  '己': '土', '庚': '金', '辛': '金', '壬': '水', '癸': '水'
};

// 地支五行对应
const ZHI_WUXING: Record<string, string> = {
  '子': '水', '丑': '土', '寅': '木', '卯': '木', '辰': '土', '巳': '火',
  '午': '火', '未': '土', '申': '金', '酉': '金', '戌': '土', '亥': '水'
};

// 时辰对应
const HOUR_ZHI = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

// 八卦
const BAGUA = ['乾', '坤', '震', '巽', '坎', '离', '艮', '兑'];

// K线数据接口
interface KLineData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// 用户命理数据
interface UserData {
  year: number;
  month: number;
  day: number;
  hour: number;
  gender: string;
  bazi: {
    year: { gan: string; zhi: string };
    month: { gan: string; zhi: string };
    day: { gan: string; zhi: string };
    hour: { gan: string; zhi: string };
  };
  wuxing: string[];
  bagua: string;
  seed: number;
}

// 人生阶段定义
const LIFE_STAGES = [
  { name: '童年', range: '0-10', startAge: 0, endAge: 10 },
  { name: '少年', range: '10-20', startAge: 10, endAge: 20 },
  { name: '青年', range: '20-30', startAge: 20, endAge: 30 },
  { name: '壮年', range: '30-40', startAge: 30, endAge: 40 },
  { name: '中年', range: '40-50', startAge: 40, endAge: 50 },
  { name: '中老年', range: '50-60', startAge: 50, endAge: 60 },
  { name: '花甲', range: '60-70', startAge: 60, endAge: 70 },
  { name: '古稀', range: '70-80', startAge: 70, endAge: 80 },
  { name: '耄耋', range: '80-90', startAge: 80, endAge: 90 }
];

// 维度配置
const DIMENSION_CONFIG: Record<string, { name: string; ageRange: { start: number; end: number } }> = {
  overall: { name: '综合运势', ageRange: { start: 0, end: 90 } },
  career: { name: '事业运', ageRange: { start: 0, end: 90 } },
  wealth: { name: '财运', ageRange: { start: 0, end: 90 } },
  love: { name: '感情运', ageRange: { start: 0, end: 90 } },
  health: { name: '健康运', ageRange: { start: 0, end: 90 } },
  investment: { name: '投资趋势', ageRange: { start: 20, end: 80 } },
  social: { name: '交友趋势', ageRange: { start: 10, end: 80 } },
  workplace: { name: '职场趋势', ageRange: { start: 18, end: 60 } }
};

// 全局状态
let userData: UserData | null = null;
let isCalculated = false;
let currentDimension = 'overall';
let mainCanvas: HTMLCanvasElement | null = null;
let mainContext: CanvasRenderingContext2D | null = null;
let mainMouseX = 0;
let mainMouseY = 0;

// 当前输入值
let inputState = {
  year: 1990,
  month: 1,
  day: 1,
  hour: 6,
  gender: 'male'
};

// 时辰名称映射
const HOUR_NAMES = [
  '子时', '丑时', '寅时', '卯时', '辰时', '巳时',
  '午时', '未时', '申时', '酉时', '戌时', '亥时'
];

// 初始化卡片式输入
function initCardInputs(): void {
  // 初始化月份选择器
  const pickerMonth = document.getElementById('pickerMonth');
  if (pickerMonth) {
    for (let m = 1; m <= 12; m++) {
      const item = document.createElement('div');
      item.className = 'picker-item' + (m === inputState.month ? ' active' : '');
      item.textContent = m + '月';
      item.setAttribute('data-value', m.toString());
      item.addEventListener('click', (e: Event) => {
        e.stopPropagation();
        selectMonth(m);
      });
      pickerMonth.appendChild(item);
    }
  }

  // 初始化时辰选择器
  const pickerHour = document.getElementById('pickerHour');
  if (pickerHour) {
    for (let h = 0; h < 12; h++) {
      const item = document.createElement('div');
      item.className = 'picker-item' + (h === inputState.hour ? ' active' : '');
      item.textContent = HOUR_NAMES[h];
      item.setAttribute('data-value', h.toString());
      item.addEventListener('click', (e: Event) => {
        e.stopPropagation();
        selectHour(h);
      });
      pickerHour.appendChild(item);
    }
  }

  // 初始化性别选择器
  const pickerGender = document.getElementById('pickerGender');
  if (pickerGender) {
    pickerGender.querySelectorAll('.gender-btn').forEach((btn: Element) => {
      btn.addEventListener('click', (e: Event) => {
        e.stopPropagation();
        const val = (btn as HTMLElement).getAttribute('data-value')!;
        selectGender(val);
      });
    });
  }

  // 卡片点击切换编辑模式
  const fields = ['Year', 'Month', 'Day', 'Hour', 'Gender'];
  fields.forEach(field => {
    const card = document.getElementById('card' + field);
    if (card) {
      card.addEventListener('click', () => {
        // 关闭其他编辑器
        fields.forEach(f => {
          if (f !== field) {
            document.getElementById('card' + f)?.classList.remove('editing');
          }
        });
        card.classList.toggle('editing');
        // 聚焦输入框
        const input = card.querySelector('.card-input') as HTMLInputElement;
        if (input) {
          setTimeout(() => input.focus(), 50);
        }
      });
    }
  });

  // 确认按钮
  document.querySelectorAll('.confirm-btn').forEach(btn => {
    btn.addEventListener('click', (e: Event) => {
      e.stopPropagation();
      const field = (btn as HTMLElement).getAttribute('data-field')!;
      confirmInput(field);
    });
  });

  // 取消按钮
  document.querySelectorAll('.cancel-btn').forEach(btn => {
    btn.addEventListener('click', (e: Event) => {
      e.stopPropagation();
      const field = (btn as HTMLElement).getAttribute('data-field')!;
      cancelInput(field);
    });
  });

  // 输入框回车确认
  document.querySelectorAll('.card-input').forEach(input => {
    input.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        const card = (input as HTMLElement).closest('.input-card');
        const field = card?.getAttribute('data-field');
        if (field) confirmInput(field);
      } else if (e.key === 'Escape') {
        const card = (input as HTMLElement).closest('.input-card');
        const field = card?.getAttribute('data-field');
        if (field) cancelInput(field);
      }
    });
    // 阻止点击事件冒泡
    input.addEventListener('click', (e: Event) => e.stopPropagation());
  });

  // 点击页面其他区域关闭编辑器
  document.addEventListener('click', (e: Event) => {
    const target = e.target as HTMLElement;
    if (!target.closest('.input-card')) {
      fields.forEach(f => {
        document.getElementById('card' + f)?.classList.remove('editing');
      });
    }
  });

  // 设置初始输入值
  const inputYear = document.getElementById('inputYear') as HTMLInputElement;
  const inputDay = document.getElementById('inputDay') as HTMLInputElement;
  if (inputYear) inputYear.value = inputState.year.toString();
  if (inputDay) inputDay.value = inputState.day.toString();
}

// 选择月份
function selectMonth(m: number): void {
  inputState.month = m;
  document.getElementById('cardMonthValue')!.textContent = m + '月';
  // 更新选中状态
  document.querySelectorAll('#pickerMonth .picker-item').forEach((item: Element) => {
    const val = parseInt(item.getAttribute('data-value')!);
    item.classList.toggle('active', val === m);
  });
  // 关闭编辑器
  document.getElementById('cardMonth')?.classList.remove('editing');
}

// 选择时辰
function selectHour(h: number): void {
  inputState.hour = h;
  document.getElementById('cardHourValue')!.textContent = HOUR_NAMES[h];
  // 更新选中状态
  document.querySelectorAll('#pickerHour .picker-item').forEach((item: Element) => {
    const val = parseInt(item.getAttribute('data-value')!);
    item.classList.toggle('active', val === h);
  });
  // 关闭编辑器
  document.getElementById('cardHour')?.classList.remove('editing');
}

// 选择性别
function selectGender(val: string): void {
  inputState.gender = val;
  document.getElementById('cardGenderValue')!.textContent = val === 'male' ? '男' : '女';
  // 更新选中状态
  document.querySelectorAll('#pickerGender .gender-btn').forEach((btn: Element) => {
    btn.classList.toggle('active', btn.getAttribute('data-value') === val);
  });
  // 关闭编辑器
  document.getElementById('cardGender')?.classList.remove('editing');
}

// 确认输入
function confirmInput(field: string): void {
  if (field === 'year') {
    const input = document.getElementById('inputYear') as HTMLInputElement;
    const val = parseInt(input.value);
    if (val >= 1940 && val <= 2024) {
      inputState.year = val;
      document.getElementById('cardYearValue')!.textContent = val + '年';
      document.getElementById('cardYear')?.classList.remove('editing');
    }
  } else if (field === 'day') {
    const input = document.getElementById('inputDay') as HTMLInputElement;
    const val = parseInt(input.value);
    if (val >= 1 && val <= 31) {
      inputState.day = val;
      document.getElementById('cardDayValue')!.textContent = val + '日';
      document.getElementById('cardDay')?.classList.remove('editing');
    }
  }
}

// 取消输入
function cancelInput(field: string): void {
  const fieldMap: Record<string, string> = { year: 'Year', month: 'Month', day: 'Day', hour: 'Hour', gender: 'Gender' };
  const cardId = 'card' + fieldMap[field];
  document.getElementById(cardId)?.classList.remove('editing');
}

// 计算天干地支
function calculateBazi(year: number, month: number, day: number, hour: number): UserData['bazi'] {
  const yearGanIndex = (year - 4) % 10;
  const yearZhiIndex = (year - 4) % 12;
  const yearGan = TIAN_GAN[yearGanIndex >= 0 ? yearGanIndex : yearGanIndex + 10];
  const yearZhi = DI_ZHI[yearZhiIndex >= 0 ? yearZhiIndex : yearZhiIndex + 12];

  const monthBase = (year - 4) * 12 + month;
  const monthGanIndex = (monthBase - 1) % 10;
  const monthGan = TIAN_GAN[monthGanIndex >= 0 ? monthGanIndex : monthGanIndex + 10];
  const monthZhi = DI_ZHI[(month + 1) % 12];

  const baseDate = new Date(1900, 0, 31);
  const targetDate = new Date(year, month - 1, day);
  const daysDiff = Math.floor((targetDate.getTime() - baseDate.getTime()) / (1000 * 60 * 60 * 24));
  const dayGanIndex = daysDiff % 10;
  const dayZhiIndex = daysDiff % 12;
  const dayGan = TIAN_GAN[dayGanIndex >= 0 ? dayGanIndex : dayGanIndex + 10];
  const dayZhi = DI_ZHI[dayZhiIndex >= 0 ? dayZhiIndex : dayZhiIndex + 12];

  const dayGanBase = dayGanIndex % 5;
  const hourGanBase = [0, 2, 4, 6, 8][dayGanBase];
  const hourGanIndex = (hourGanBase + hour) % 10;
  const hourGan = TIAN_GAN[hourGanIndex];
  const hourZhi = HOUR_ZHI[hour];

  return {
    year: { gan: yearGan, zhi: yearZhi },
    month: { gan: monthGan, zhi: monthZhi },
    day: { gan: dayGan, zhi: dayZhi },
    hour: { gan: hourGan, zhi: hourZhi }
  };
}

// 计算五行
function calculateWuxing(bazi: UserData['bazi']): string[] {
  const wuxingSet = new Set<string>();
  wuxingSet.add(GAN_WUXING[bazi.year.gan]);
  wuxingSet.add(ZHI_WUXING[bazi.year.zhi]);
  wuxingSet.add(GAN_WUXING[bazi.month.gan]);
  wuxingSet.add(ZHI_WUXING[bazi.month.zhi]);
  wuxingSet.add(GAN_WUXING[bazi.day.gan]);
  wuxingSet.add(ZHI_WUXING[bazi.day.zhi]);
  wuxingSet.add(GAN_WUXING[bazi.hour.gan]);
  wuxingSet.add(ZHI_WUXING[bazi.hour.zhi]);
  return Array.from(wuxingSet);
}

// 计算对应八卦
function calculateBagua(year: number, month: number, day: number, hour: number): string {
  const sum = year + month + day + hour;
  return BAGUA[sum % 8];
}

// 伪随机数生成器
function seededRandom(seed: number): number {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

// 根据维度获取有效阶段
function getValidStages(dimension: string): { name: string; range: string; startAge: number; endAge: number }[] {
  const config = DIMENSION_CONFIG[dimension];
  if (!config) return LIFE_STAGES;
  
  const { start, end } = config.ageRange;
  return LIFE_STAGES.filter(stage => stage.endAge > start && stage.startAge < end);
}

// 生成K线数据
function generateKLineData(seed: number, dimension: string): KLineData[] {
  const data: KLineData[] = [];
  const stages = getValidStages(dimension);
  
  const dimensionMod: Record<string, number> = {
    overall: 0, career: 1, wealth: 2, love: 3, health: 4,
    investment: 5, social: 6, workplace: 7
  };

  for (let i = 0; i < stages.length; i++) {
    const stageSeed = seed + dimensionMod[dimension] * 1000 + i * 100;
    
    const base = 50 + seededRandom(stageSeed) * 30;
    const volatility = 10 + seededRandom(stageSeed + 1) * 15;
    
    const open = base + (seededRandom(stageSeed + 2) - 0.5) * volatility;
    const close = base + (seededRandom(stageSeed + 3) - 0.5) * volatility;
    const high = Math.max(open, close) + seededRandom(stageSeed + 4) * volatility * 0.5;
    const low = Math.min(open, close) - seededRandom(stageSeed + 5) * volatility * 0.5;

    data.push({
      time: `${stages[i].name} (${stages[i].range}岁)`,
      open: Math.max(10, Math.min(100, open)),
      high: Math.max(10, Math.min(100, high)),
      low: Math.max(10, Math.min(100, low)),
      close: Math.max(10, Math.min(100, close)),
      volume: Math.floor(seededRandom(stageSeed + 6) * 100 + 50)
    });
  }

  return data;
}

// 显示用户信息
function displayUserInfo(user: UserData): void {
  const baziDisplay = document.getElementById('baziDisplay')!;
  baziDisplay.innerHTML = `
    <div class="bazi-item">
      <div class="label">年柱</div>
      <div class="value">${user.bazi.year.gan}${user.bazi.year.zhi}</div>
    </div>
    <div class="bazi-item">
      <div class="label">月柱</div>
      <div class="value">${user.bazi.month.gan}${user.bazi.month.zhi}</div>
    </div>
    <div class="bazi-item">
      <div class="label">日柱</div>
      <div class="value">${user.bazi.day.gan}${user.bazi.day.zhi}</div>
    </div>
    <div class="bazi-item">
      <div class="label">时柱</div>
      <div class="value">${user.bazi.hour.gan}${user.bazi.hour.zhi}</div>
    </div>
  `;

  const wuxingDisplay = document.getElementById('wuxingDisplay')!;
  const wuxingClassMap: Record<string, string> = {
    '金': 'gold', '木': 'wood', '水': 'water', '火': 'fire', '土': 'earth'
  };
  wuxingDisplay.innerHTML = user.wuxing.map(w => 
    `<span class="wuxing-tag ${wuxingClassMap[w]}">${w}</span>`
  ).join('');
}

// 生成今日运势
function generateTodayFortune(user: UserData): void {
  const today = new Date();
  const dateSeed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
  const baseSeed = user.seed + dateSeed;
  
  const dateStr = `${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日`;
  const weekDays = ['日', '一', '二', '三', '四', '五', '六'];
  const weekDay = weekDays[today.getDay()];
  document.getElementById('todayDate')!.textContent = `📅 ${dateStr} 星期${weekDay}`;
  
  const score = Math.floor(50 + seededRandom(baseSeed) * 50);
  document.getElementById('todayScore')!.textContent = score + '分';
  document.getElementById('todayScore')!.className = 'score-value ' + (score >= 80 ? 'high' : score >= 60 ? 'medium' : 'low');
  
  const items = [
    { name: '事业运', icon: '💼', seed: baseSeed + 1 },
    { name: '财运', icon: '💰', seed: baseSeed + 2 },
    { name: '感情运', icon: '❤️', seed: baseSeed + 3 },
    { name: '健康运', icon: '💪', seed: baseSeed + 4 },
    { name: '贵人运', icon: '🌟', seed: baseSeed + 5 }
  ];
  
  const fortuneItems = document.getElementById('fortuneItems')!;
  fortuneItems.innerHTML = items.map(item => {
    const value = Math.floor(seededRandom(item.seed) * 100);
    const level = value >= 80 ? 'high' : value >= 50 ? 'medium' : 'low';
    return `
      <div class="fortune-item">
        <span class="item-icon">${item.icon}</span>
        <span class="item-name">${item.name}</span>
        <div class="item-bar">
          <div class="bar-fill ${level}" style="width: ${value}%"></div>
        </div>
        <span class="item-value">${value}</span>
      </div>
    `;
  }).join('');
}

// 生成穿搭指南
function generateOutfitGuide(user: UserData): void {
  const today = new Date();
  const dateSeed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
  const baseSeed = user.seed + dateSeed + 1000;
  
  const dateStr = `${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日`;
  const weekDays = ['日', '一', '二', '三', '四', '五', '六'];
  const weekDay = weekDays[today.getDay()];
  document.getElementById('outfitDate')!.textContent = `📅 ${dateStr} 星期${weekDay}`;
  
  const colorPalette = [
    { color: '#FFD700', name: '金色', meaning: '招财进宝' },
    { color: '#FF6B6B', name: '红色', meaning: '鸿运当头' },
    { color: '#4ECDC4', name: '青色', meaning: '平安顺遂' },
    { color: '#45B7D1', name: '蓝色', meaning: '智慧通达' },
    { color: '#96CEB4', name: '绿色', meaning: '生机勃勃' },
    { color: '#DDA0DD', name: '紫色', meaning: '贵人相助' }
  ];
  
  const wuxingColors: Record<string, number[]> = {
    '金': [0, 5], '木': [4, 2], '水': [3, 2], '火': [1, 0], '土': [4, 3]
  };
  
  const userWuxing = user.wuxing[0] || '水';
  const colorIndices = wuxingColors[userWuxing] || [0, 1];
  const luckyColors = colorIndices.map(i => colorPalette[i]);
  
  const colorSwatches = document.getElementById('luckyColors')!;
  colorSwatches.innerHTML = luckyColors.map(c => 
    `<div class="color-swatch" style="background-color: ${c.color}" title="${c.name}: ${c.meaning}"></div>`
  ).join('');
  
  const styles = [
    { style: '简约商务风', desc: '适合重要会议或商务洽谈' },
    { style: '休闲运动风', desc: '适合户外活动或日常出行' },
    { style: '优雅知性风', desc: '适合社交场合，彰显品味' }
  ];
  
  const selectedStyle = styles[Math.floor(seededRandom(baseSeed + 100) * styles.length)];
  
  const outfitStyle = document.getElementById('outfitStyle')!;
  outfitStyle.innerHTML = `
    <div class="style-name">今日推荐：${selectedStyle.style}</div>
    <div class="style-desc">${selectedStyle.desc}</div>
  `;
}

// 生成综合分析指南
function generateAnalysisGuide(user: UserData): void {
  const baseSeed = user.seed;
  
  const personalities = [
    { trait: '稳重踏实', desc: '做事认真负责，有条不紊' },
    { trait: '热情开朗', desc: '积极乐观，善于交际' },
    { trait: '聪明机敏', desc: '思维敏捷，反应迅速' }
  ];
  
  const wuxingStrength: Record<string, string[]> = {
    '金': ['果断坚毅', '重义守信'],
    '木': ['仁慈善良', '积极向上'],
    '水': ['智慧通达', '灵活应变'],
    '火': ['热情洋溢', '积极进取'],
    '土': ['踏实稳重', '诚实守信']
  };
  
  const userWuxing = user.wuxing[0] || '水';
  const wuxingTraits = wuxingStrength[userWuxing] || wuxingStrength['水'];
  const personality = personalities[Math.floor(seededRandom(baseSeed) * personalities.length)];
  
  const advices = [
    { area: '事业', advice: '稳扎稳打，循序渐进' },
    { area: '财运', advice: '宜守不宜攻，稳健投资' },
    { area: '感情', advice: '真诚待人，缘到自然成' },
    { area: '健康', advice: '注意作息规律，劳逸结合' }
  ];
  
  const luckyDirections = ['东方', '南方', '西方', '北方'];
  const luckyDirection = luckyDirections[Math.floor(seededRandom(baseSeed + 500) * luckyDirections.length)];
  
  const analysisSummary = document.getElementById('analysisSummary')!;
  analysisSummary.innerHTML = `
    <div class="summary-title">性格特质</div>
    <div class="trait-main">${personality.trait}</div>
    <div class="trait-desc">${personality.desc}</div>
    <div class="wuxing-traits">
      ${wuxingTraits.map(t => `<span class="trait-tag">${t}</span>`).join('')}
    </div>
  `;
  
  const analysisTips = document.getElementById('analysisTips')!;
  analysisTips.innerHTML = `
    <div class="tips-title">人生发展建议</div>
    ${advices.map(a => `
      <div class="tip-item">
        <span class="tip-area">${a.area}</span>
        <span class="tip-advice">${a.advice}</span>
      </div>
    `).join('')}
    <div class="lucky-info">
      <div class="lucky-item">
        <span class="lucky-label">幸运方位</span>
        <span class="lucky-value">${luckyDirection}</span>
      </div>
    </div>
  `;
}

// 生成避坑指南
function generatePitfallGuides(user: UserData): void {
  const baseSeed = user.seed;
  
  // 投资避坑指南
  const investmentTips = [
    { title: '避免冲动投资', desc: '投资前充分调研，不要被短期高收益诱惑' },
    { title: '分散风险', desc: '不要把所有资金投入单一项目，合理配置资产' },
    { title: '警惕高利诱惑', desc: '收益率过高的项目往往风险极大，需谨慎' },
    { title: '控制杠杆', desc: '避免过度借贷投资，量力而行' }
  ];
  
  const investmentGuide = document.getElementById('investmentGuide')!;
  investmentGuide.innerHTML = investmentTips.map((tip, i) => `
    <div class="guide-tip">
      <div class="tip-icon">⚠️</div>
      <div class="tip-content">
        <div class="tip-title">${tip.title}</div>
        <div class="tip-desc">${tip.desc}</div>
      </div>
    </div>
  `).join('');
  
  // 交友避坑指南
  const socialTips = [
    { title: '识人要慢', desc: '真正了解一个人需要时间，不要急于深交' },
    { title: '警惕利益关系', desc: '纯粹利益驱动的友谊难以长久' },
    { title: '保持边界感', desc: '适度的距离让友谊更持久' },
    { title: '远离负能量', desc: '经常抱怨的人会影响你的心态' }
  ];
  
  const socialGuide = document.getElementById('socialGuide')!;
  socialGuide.innerHTML = socialTips.map((tip, i) => `
    <div class="guide-tip">
      <div class="tip-icon">🚫</div>
      <div class="tip-content">
        <div class="tip-title">${tip.title}</div>
        <div class="tip-desc">${tip.desc}</div>
      </div>
    </div>
  `).join('');
  
  // 职场避坑指南
  const workplaceTips = [
    { title: '谨言慎行', desc: '职场中言多必失，学会倾听' },
    { title: '避免越级汇报', desc: '尊重层级关系，按流程办事' },
    { title: '不要站队', desc: '远离办公室政治，专注提升自己' },
    { title: '留存证据', desc: '重要沟通保留书面记录' }
  ];
  
  const workplaceGuide = document.getElementById('workplaceGuide')!;
  workplaceGuide.innerHTML = workplaceTips.map((tip, i) => `
    <div class="guide-tip">
      <div class="tip-icon">💼</div>
      <div class="tip-content">
        <div class="tip-title">${tip.title}</div>
        <div class="tip-desc">${tip.desc}</div>
      </div>
    </div>
  `).join('');
  
  // 创业避坑指南
  const startupTips = [
    { title: '市场验证先行', desc: '创业前先验证市场需求，避免盲目投入' },
    { title: '现金流为王', desc: '保持充足的现金流，避免资金链断裂' },
    { title: '团队很关键', desc: '选择志同道合、能力互补的合伙人' },
    { title: '小步快跑', desc: '先做最小可行产品，快速迭代验证' }
  ];
  
  const startupGuide = document.getElementById('startupGuide')!;
  startupGuide.innerHTML = startupTips.map((tip, i) => `
    <div class="guide-tip">
      <div class="tip-icon">🎯</div>
      <div class="tip-content">
        <div class="tip-title">${tip.title}</div>
        <div class="tip-desc">${tip.desc}</div>
      </div>
    </div>
  `).join('');
}

// 初始化主Canvas
function initMainCanvas(): void {
  mainCanvas = document.getElementById('mainKlineCanvas') as HTMLCanvasElement;
  if (!mainCanvas) return;
  
  const container = document.getElementById('mainCanvasContainer')!;
  const rect = container.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  
  mainCanvas.width = rect.width * dpr;
  mainCanvas.height = rect.height * dpr;
  mainCanvas.style.width = rect.width + 'px';
  mainCanvas.style.height = rect.height + 'px';
  
  mainContext = mainCanvas.getContext('2d');
  mainContext!.scale(dpr, dpr);
}

// 绘制K线图
function drawKLine(data: KLineData[], mouseXPos: number, mouseYPos: number): void {
  if (!mainContext || !mainCanvas) return;
  
  const ctx2d = mainContext;
  const container = document.getElementById('mainCanvasContainer')!;
  const rect = container.getBoundingClientRect();
  const width = rect.width;
  const height = rect.height;
  
  ctx2d.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx2d.fillRect(0, 0, width, height);

  if (data.length === 0) return;

  const padding = { top: 30, right: 60, bottom: 50, left: 20 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  
  const candleWidth = chartWidth / data.length;
  const hoveredIndex = Math.floor((mouseXPos - padding.left) / candleWidth);
  const validHover = hoveredIndex >= 0 && hoveredIndex < data.length;

  const mouseRatio = mouseXPos / width;
  const offsetY = Math.sin(mouseRatio * Math.PI * 2) * 3;
  const offsetX = Math.cos(mouseRatio * Math.PI * 2) * 2;

  // 绘制网格
  ctx2d.strokeStyle = 'rgba(255, 255, 255, 0.05)';
  ctx2d.lineWidth = 1;
  for (let i = 0; i <= 5; i++) {
    const y = padding.top + (chartHeight / 5) * i;
    ctx2d.beginPath();
    ctx2d.moveTo(padding.left, y);
    ctx2d.lineTo(width - padding.right, y);
    ctx2d.stroke();
  }

  // 绘制Y轴刻度
  ctx2d.fillStyle = '#8892b0';
  ctx2d.font = '12px sans-serif';
  ctx2d.textAlign = 'left';
  for (let i = 0; i <= 5; i++) {
    const value = 100 - i * 20;
    const y = padding.top + (chartHeight / 5) * i;
    ctx2d.fillText(value.toString(), width - padding.right + 10, y + 4);
  }

  // 计算价格范围
  let minPrice = Infinity, maxPrice = -Infinity;
  data.forEach(d => {
    minPrice = Math.min(minPrice, d.low);
    maxPrice = Math.max(maxPrice, d.high);
  });
  minPrice = Math.max(0, minPrice - 5);
  maxPrice = maxPrice + 5;

  // 绘制K线蜡烛
  data.forEach((candle, index) => {
    const x = padding.left + candleWidth * index + candleWidth / 2;
    const isHovered = index === hoveredIndex;
    
    const mouseYRatio = mouseYPos / height;
    const dynamicFactor = 1 + (mouseYRatio - 0.5) * 0.1;
    
    const open = (candle.open - minPrice) / (maxPrice - minPrice) * chartHeight * dynamicFactor;
    const close = (candle.close - minPrice) / (maxPrice - minPrice) * chartHeight * dynamicFactor;
    const high = (candle.high - minPrice) / (maxPrice - minPrice) * chartHeight * dynamicFactor;
    const low = (candle.low - minPrice) / (maxPrice - minPrice) * chartHeight * dynamicFactor;

    const isUp = close >= open;
    const color = isUp ? '#ef5350' : '#26a69a';
    
    const adjustedX = x + offsetX;

    // 绘制影线
    ctx2d.beginPath();
    ctx2d.strokeStyle = isHovered ? '#64ffda' : color;
    ctx2d.lineWidth = isHovered ? 2 : 1;
    ctx2d.moveTo(adjustedX, padding.top + chartHeight - high);
    ctx2d.lineTo(adjustedX, padding.top + chartHeight - low);
    ctx2d.stroke();

    // 绘制实体
    const bodyTop = padding.top + chartHeight - Math.max(open, close);
    const bodyHeight = Math.abs(close - open);
    const barWidth = Math.min(candleWidth * 0.6, 30);
    
    ctx2d.fillStyle = isHovered ? '#64ffda' : color;
    ctx2d.fillRect(adjustedX - barWidth / 2, bodyTop, barWidth, Math.max(bodyHeight, 2));

    // 绘制X轴标签
    ctx2d.fillStyle = isHovered ? '#64ffda' : '#8892b0';
    ctx2d.font = isHovered ? 'bold 10px sans-serif' : '10px sans-serif';
    ctx2d.textAlign = 'center';
    const shortName = candle.time.split(' ')[0];
    ctx2d.fillText(shortName, x, height - padding.bottom + 15);
  });

  // 绘制十字光标
  if (validHover && mouseXPos > padding.left && mouseXPos < width - padding.right) {
    ctx2d.strokeStyle = 'rgba(100, 255, 218, 0.5)';
    ctx2d.lineWidth = 1;
    ctx2d.setLineDash([5, 5]);
    
    ctx2d.beginPath();
    ctx2d.moveTo(mouseXPos, padding.top);
    ctx2d.lineTo(mouseXPos, height - padding.bottom);
    ctx2d.stroke();
    
    ctx2d.beginPath();
    ctx2d.moveTo(padding.left, mouseYPos);
    ctx2d.lineTo(width - padding.right, mouseYPos);
    ctx2d.stroke();
    
    ctx2d.setLineDash([]);

    updateTooltip(data[hoveredIndex], mouseXPos, mouseYPos);
    updateInfoBar(data[hoveredIndex]);
  }
}

// 更新tooltip
function updateTooltip(data: KLineData, x: number, y: number): void {
  const tooltip = document.getElementById('mainTooltip')!;
  const container = document.getElementById('mainCanvasContainer')!;
  const rect = container.getBoundingClientRect();
  
  const isUp = data.close >= data.open;
  
  tooltip.innerHTML = `
    <div class="tooltip-title">时期：${data.time}</div>
    <div class="tooltip-row">
      <span class="tooltip-label">运势开盘</span>
      <span class="tooltip-value ${isUp ? 'up' : 'down'}">${data.open.toFixed(1)}</span>
    </div>
    <div class="tooltip-row">
      <span class="tooltip-label">运势收盘</span>
      <span class="tooltip-value ${isUp ? 'up' : 'down'}">${data.close.toFixed(1)}</span>
    </div>
    <div class="tooltip-row">
      <span class="tooltip-label">最高运势</span>
      <span class="tooltip-value">${data.high.toFixed(1)}</span>
    </div>
    <div class="tooltip-row">
      <span class="tooltip-label">最低运势</span>
      <span class="tooltip-value">${data.low.toFixed(1)}</span>
    </div>
  `;
  
  tooltip.classList.add('active');
  
  let tooltipX = x + 15;
  let tooltipY = y - 60;
  if (tooltipX + 180 > rect.width) tooltipX = x - 180;
  if (tooltipY < 10) tooltipY = 10;
  
  tooltip.style.left = tooltipX + 'px';
  tooltip.style.top = tooltipY + 'px';
}

// 更新信息栏
function updateInfoBar(data: KLineData): void {
  const isUp = data.close >= data.open;
  const avgValue = ((data.open + data.close) / 2).toFixed(1);
  
  document.getElementById('mainCurrentValue')!.textContent = avgValue;
  document.getElementById('mainCurrentValue')!.style.color = isUp ? '#ef5350' : '#26a69a';
  
  document.getElementById('mainTrendValue')!.textContent = isUp ? '上升 ↗' : '下降 ↘';
  document.getElementById('mainTrendValue')!.style.color = isUp ? '#ef5350' : '#26a69a';
  
  const avgNum = parseFloat(avgValue);
  document.getElementById('mainWuxingStrength')!.textContent = avgNum > 60 ? '五行平衡' : avgNum > 40 ? '五行偏弱' : '五行不足';
  
  const suggestions = ['稳中求进', '开拓创新', '守成为主', '积极进取', '蓄势待发', '把握机遇', '谨慎行事', '顺势而为'];
  document.getElementById('mainSuggestion')!.textContent = suggestions[Math.floor(data.close / 12.5)];
}

// 鼠标/触摸事件处理
function handlePointerMove(e: MouseEvent | TouchEvent): void {
  const container = document.getElementById('mainCanvasContainer')!;
  const rect = container.getBoundingClientRect();
  
  let clientX: number, clientY: number;
  if ('touches' in e) {
    clientX = e.touches[0].clientX;
    clientY = e.touches[0].clientY;
  } else {
    clientX = e.clientX;
    clientY = e.clientY;
  }
  
  mainMouseX = Math.max(0, Math.min(clientX - rect.left, rect.width));
  mainMouseY = Math.max(0, Math.min(clientY - rect.top, rect.height));
  
  const seed = isCalculated && userData ? userData.seed : 19900101;
  const klineData = generateKLineData(seed, currentDimension);
  drawKLine(klineData, mainMouseX, mainMouseY);
}

// 切换维度
function switchDimension(dimension: string): void {
  currentDimension = dimension;
  
  document.querySelectorAll('#mainDimensionTabs .dimension-tab').forEach(tab => {
    tab.classList.toggle('active', tab.getAttribute('data-dimension') === dimension);
  });
  
  const seed = isCalculated && userData ? userData.seed : 19900101;
  const klineData = generateKLineData(seed, dimension);
  drawKLine(klineData, mainMouseX, mainMouseY);
}

// 开始推算
function startCalculation(): void {
  const year = inputState.year;
  const month = inputState.month;
  const day = inputState.day;
  const hour = inputState.hour;
  const gender = inputState.gender;

  const bazi = calculateBazi(year, month, day, hour);
  const wuxing = calculateWuxing(bazi);
  const bagua = calculateBagua(year, month, day, hour);

  userData = {
    year, month, day, hour, gender,
    bazi, wuxing, bagua,
    seed: year * 10000 + month * 100 + day + hour * 0.1
  };
  
  isCalculated = true;

  // 更新标签显示
  document.getElementById('mainKlineBadge')!.textContent = '您的结果';
  document.getElementById('mainKlineBadge')!.style.background = 'linear-gradient(135deg, #4ade80, #22c55e)';

  // 显示用户信息
  displayUserInfo(userData);

  // 生成各项内容
  generateTodayFortune(userData);
  generateOutfitGuide(userData);
  generateAnalysisGuide(userData);
  generatePitfallGuides(userData);

  // 显示结果区域
  document.getElementById('resultSection')!.classList.add('active');

  // 更新K线图
  const klineData = generateKLineData(userData.seed, currentDimension);
  drawKLine(klineData, mainMouseX, mainMouseY);
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
  initCardInputs();
  
  // 初始化主K线图
  setTimeout(() => {
    initMainCanvas();
    if (!mainCanvas) return;
    
    const container = document.getElementById('mainCanvasContainer')!;
    const rect = container.getBoundingClientRect();
    mainMouseX = rect.width / 2;
    mainMouseY = rect.height / 2;
    
    // 绑定事件
    container.addEventListener('mousemove', handlePointerMove);
    container.addEventListener('touchmove', handlePointerMove, { passive: true });
    
    // 绑定维度切换
    document.querySelectorAll('#mainDimensionTabs .dimension-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        switchDimension(tab.getAttribute('data-dimension')!);
      });
    });
    
    // 初始绘制示范K线
    const demoData = generateKLineData(19900101, currentDimension);
    drawKLine(demoData, mainMouseX, mainMouseY);
  }, 100);
  
  // 绑定计算按钮
  document.getElementById('calculateBtn')!.addEventListener('click', startCalculation);
  
  // 窗口大小改变
  window.addEventListener('resize', () => {
    initMainCanvas();
    const seed = isCalculated && userData ? userData.seed : 19900101;
    const klineData = generateKLineData(seed, currentDimension);
    drawKLine(klineData, mainMouseX, mainMouseY);
  });
});
